
pi=100;% this value   
beta=1; % beta_h
mu=0.172;     % beta_v
gamma=0.5;    
delta=0.15;  % mu_h
phi=0.2;        %mu_v
p=0.3;    

alpha= 0.70; % this is the order of the fractional derivtives, try values such as: 1, 0.99, 0.95, 0.90, 0.85, etc
% S=y(1)
% E=y(2)
% I=y(3)
% Q=y(4)
% R=y(5)

fdefun = @(t,y)[pi-beta*y(1)*y(3) - mu*y(1); beta*y(1)*y(3) - (gamma + mu)*y(2); 
    gamma*y(2) - (delta + mu)*y(3) + (1-p)*phi*y(4);
    delta*y(3) - (p*phi  + mu)*y(4); phi*y(4) - mu*y(5)]; 

t0 = 0 ; tfinal = 100 ; y0=[800; 5; 1; 5; 5]; % y0 is the initial condition for the state vriables
h = 0.001 ;
[t, y_fde12] = fde12(alpha,fdefun,t0,tfinal,y0,h) ;

%plot(t, y_fde12(1,:),'r -') % this plot is for S_h
%hold on 
%plot(t, y_fde12(2,:),'k -.','LineWidth',1) % this plot is for I_h
hold on
%plot(t, y_fde12(5,:),'k -.','LineWidth',1)  % this plot is for R_h

 hleg1 = legend('u = 0.50');
 xlabel('\bf t');
ylabel('\bf E');
 hold on
 hold on